bool isPalindrome(int x) {
        long long n1=x;
        long long sum=0;
        if(x<0)
        return false;
        while(x!=0)
        {
            int d=x%10;
            sum=sum*10+d;
            x=x/10;
        }
        return (sum==n1);
    }
