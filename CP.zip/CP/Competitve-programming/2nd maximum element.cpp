int print2largest(int arr[], int n) {
        sort(arr,arr+n);
        int l=n-1;
        int maxi = arr[l];
        int smax=-1;
        for(int i=n-2;i>=0;i--) {
            if(arr[i]<maxi){
                smax = arr[i];
                break;
            }
        }
        return smax;
	}
