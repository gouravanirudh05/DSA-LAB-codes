int reverse(int x) 
    {
        int d=0;
        while(x)
        {
            if(d>INT_MAX/10 || d<INT_MIN/10)
                return 0;
            d=d*10+x%10;
            x=x/10;
        }
        return d;

        
    }
