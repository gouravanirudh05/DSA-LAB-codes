#include<bits/stdc++.h>
using namespace std;
using ll=long long int;
int main()
{
    ll t;
    cin>>t;
    while(t--)
    {
        ll n;
        cin>>n;
        ll a[n];
        for(ll i=0;i<n;i++)
        {
            cin>>a[i];
        }
        int sum=a[n-1];
        sort(a,a+n);
        cout<<sum+a[0]<<endl;
    }
}