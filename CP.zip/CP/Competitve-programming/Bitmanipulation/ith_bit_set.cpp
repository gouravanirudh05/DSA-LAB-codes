#include<bits/stdc++.h>
using namespace std;
using ll=long long int;

string convert_to_bin(ll n)
{
    //Function to convert a number to a binary representation
    string binary = "";
    while(n > 0)
    {
        binary = to_string(n % 2) + binary;
        n /= 2;
    }
    return binary;
}
ll convert_to_decimal(string n)
{
    //Function to convert a binary number to a decimal representation
    ll decimal = 0;
    for(int i = 0; i < n.size(); i++)
    {
        decimal += (n[i] - '0') * pow(2, n.size() - i - 1);
    }
    return decimal;
}

bool i_th_bit_set(ll n,ll i)
{
    //Function to check if the i-th bit is set in the binary representation of n
    return (n & (1 << (sizeof(ll) * 8 - 1) - i))!= 0;
    //Using right shift
    return (n >> i) & 1;
}

void set_ith_bit(ll n,ll i)
{
    //Function to set the i-th bit in the binary representation of n
  
    n=n|(1<<i);
}

void clear_ith_bit(ll n, ll i)
{   
    n=n&(!(1<<i));
}

void toggle_ith_bit(ll n, ll i)
{
    //Function to toggle the i-th bit in the binary representation of n
    n=n^(1<<i); 
}

ll right_most_set_bit(ll n)
{
    //Function to find the position of the rightmost set bit in the binary representation of n
    ll pos = 0;
    while((n & (1 << pos)) == 0)
        pos++;
    return pos;
    //Using bitwise AND operator
    return __builtin_ffsll(n) - 1;
}
void remove_the_righmost_set_bit(ll n)
{   
    //Function to remove the rightmost set bit in the binary representation of n
    n=n&(n-1);
}

ll count_set_bits(ll n)
{
    //Function to count the number of set bits in the binary representation of n
    ll count = 0;
    while(n > 0)
    {
        count += n & 1;
        n >>= 1;
    }
    return count;
    //Using bitwise AND operator
    return __builtin_popcountll(n);
}

void swap(ll a,ll b)
{
    a=(a^b)^a;
    b=(a^b)^b;
}
int main()
{

}