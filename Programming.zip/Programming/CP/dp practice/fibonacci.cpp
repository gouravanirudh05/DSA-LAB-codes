#include<bits/stdc+.h>
using namespace std;
using ll=long long int;
int main()
{
    ll n;
    cin>>n;
    //Fibonacci using DP
    ll f[n+1];
    f[0]=0;
    f[1]=1;
    for(ll i=2;i<=n;i++)
    {
        f[i]=f[i-1]+f[i-2];
    }
    cout<<f[n]<<endl;

    //Fibonacci using recursion
    ll fib(ll n)
    {
        if(n<=1)
            return n;
        return fib(n-1)+fib(n-2);
    }
    cout<<fib(n)<<endl;
    //Fibonacci using space optimization with two varibles
    ll a=0,b=1;
    for(int i=2;i<=n;i++)
    {
        ll c=a+b;
        a=b;
        b=c;
    }
    return 0;
}