#include <bits/stdc++.h>
using namespace std;
using ll = long long int;
int main()
{
    ll n;
    cin >> n;
    vector<pair<ll,ll>> a(n);

    for (auto &i : a)
    {
        cin>>i.first>>i.second;
    }
    ll area=0;
    for(ll i=0;i<n;i++)
    {
        area+=(a[i].first*a[(i+1)%n].second-a[(i+1)%n].first*a[i].second);
    }

    cout<<abs(area)<<endl;
}
