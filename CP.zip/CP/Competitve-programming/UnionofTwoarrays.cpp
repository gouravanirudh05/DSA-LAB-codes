vector<int> findUnion(int arr1[], int arr2[], int n, int m)
    {
        //Your code here
        //return vector with correct order of elements
        map<int, int>mp;
        vector<int>ans;
        for(int i=0; i<n; i++){
            ans.push_back(arr1[i]);
            mp[arr1[i]]++;
        }
        for(int i=0; i<m; i++){
            if(mp.find(arr2[i])==mp.end()) ans.push_back(arr2[i]);
        }
        sort(ans.begin(), ans.end());
        ans.erase(unique(ans.begin(), ans.end()), ans.end());
        return ans;
    }
