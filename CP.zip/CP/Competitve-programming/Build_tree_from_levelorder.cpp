void create_tree(node* root0, vector<int> &vec){
        queue<node*>q;
        q.push(root0);
        int i=1;
        while(!q.empty() && i<6){
            node *temp= q.front();
            node *leftNode = newNode(vec[i++]);
            node *rightNode = newNode(vec[i++]);
            temp->left = leftNode;
            temp->right = rightNode;
            q.push(leftNode);
            q.push(rightNode);
            q.pop();
        }
    }
