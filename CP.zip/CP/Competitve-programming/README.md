# Competitve-programming
All the small codes which can be reused
