// background.js

let tabStates = {};

chrome.tabs.onActivated.addListener((activeInfo) => {
  const tabId = activeInfo.tabId;
  
  // Pause video when switching away from tab
  if (tabStates[tabId] && tabStates[tabId].playing) {
    chrome.tabs.executeScript(tabId, {
      code: `
        const video = document.querySelector('video');
        if (video && !video.paused) {
          video.pause();
        }
      `
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Update tab state when receiving message from content script
  if (message.type === 'playbackStateChange') {
    tabStates[sender.tab.id] = {
      playing: message.playing
    };
  }
});
