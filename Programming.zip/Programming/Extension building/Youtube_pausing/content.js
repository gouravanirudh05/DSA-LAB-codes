// content.js

const video = document.querySelector('video');

if (video) {
  // Send message to background script when playback state changes
  video.addEventListener('play', () => {
    chrome.runtime.sendMessage({ type: 'playbackStateChange', playing: true });
  });

  video.addEventListener('pause', () => {
    chrome.runtime.sendMessage({ type: 'playbackStateChange', playing: false });
  });
}
