#include<bits/stdc++.h>
using namespace std;
using ll=long long int;
int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}
int main(){
	int t;
	cin>>t;
	while(t--){
		ll n;
        cin>>n;
        vector<int>a(n);
        for(auto&i:a)
            cin>>i;
        vector<int>g;
        for(auto i=0;i<n-1;i++)
        {
            g.push_back(gcd(a[i],a[i+1]));
        }
        bool flag=false;
        for(int i=0;i<n-2;i++)
        {
            if(g[i]>g[i+1])
            {
                flag=true;
                break;
            }
        }
        if(flag==false)
        {
            cout<<"YES"<<endl;
            continue;
        }
        
	}
}